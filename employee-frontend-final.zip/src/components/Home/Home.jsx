import './Home.css'
import React from 'react';
import {Link} from "react-router-dom"
import Logo from '../../assets/office.png';
 
const Home = () => {
return (
    <div className='background'>
    <nav>
    <ul>
    <li className='logo-text'>
        <Link to="/home" > E Y </Link>
    </li>
    <li className='employees'>
        <Link to="/employees"> Employees </Link>
    </li>
    <li className='leave'>
        <Link to="/leaves"> Leave </Link>
    </li>
    <li className='event'>
        <Link to="/events"> Events </Link>
    </li>
    </ul>
</nav>
<img src="https://images.business.com/app/uploads/2017/10/24081927/improving-your-office-environment.png" alt="image" />
    </div>
 
)
}
 
export default Home;