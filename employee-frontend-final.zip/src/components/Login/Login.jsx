import React, { useState } from 'react';
import './Login.css';
import Logo from '../../assets/images.png';
import { useNavigate } from 'react-router-dom'; // Import useNavigate hook
 
const Login = ({ onLogin }) => {
    const navigate = useNavigate(); // Initialize the navigate function
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
 
    const handleLogin = () => {
        // Call the onLogin function passed from the parent component (App.jsx)
        onLogin(username, password, navigate);
    };
 
    return (
        <div className="container">
            <div className="login-form">
                <img src={Logo} alt="Logo" />
               
                {/* Input fields for username and password */}
               
                <input type="text"  id="username"placeholder="Enter your username" value={username} onChange={(e) => setUsername(e.target.value)} />
               
                <input type="password"id="Password" placeholder="Enter your Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                {/* Login button */}
             
                <button className="button" onClick={handleLogin}>Login</button>
           
            </div>
        </div>
    );
};
 
export default Login;