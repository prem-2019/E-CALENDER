import CalendarEvent from './CalendarEvent'



export default function Events(){
    return (
        <div>
        <CalendarEvent />
      </div>
    )
}