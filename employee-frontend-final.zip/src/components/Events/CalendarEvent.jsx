import React from 'react'
import {Day, Inject, Month, ScheduleComponent, ViewDirective, ViewsDirective, Week} from "@syncfusion/ej2-react-schedule";
import {registerLicense} from "@syncfusion/ej2-base";
registerLicense(
    "Ngo9BigBOggjHTQxAR8/V1NBaF5cXmZCe0x0TXxbf1x0ZFxMYlxbRXBPIiBoS35RckVnW3dccXZVR2dbVU10"
);

const data = [
    {
        Id: 1,
        Subject: "Sales Presentation",
        StartTime: new Date(2024, 4, 29, 10, 0),
        EndTime: new Date(2024, 4, 29, 12, 30),
        IsAllDay: false,
    },
    {
        Id: 2,
        Subject: "New Report Generation",
        StartTime: new Date(2024, 4, 29, 12, 35),
        EndTime: new Date(2024, 4, 29, 14, 30),
        IsAllDay: true,
        Status: "Completed",
        Priority: "High",
    }
]


function CalendarEvent() {
  return (
    <main>
        <ScheduleComponent
        eventSettings={{
            dataSource: data,
        }}
        currentView="Month"
        >
            <ViewsDirective>
                <ViewDirective option="Day" />
                <ViewDirective option="Week" />
                <ViewDirective option="Month" />
            </ViewsDirective>
            <Inject services={[Day, Week, Month]} />
        </ScheduleComponent>
    </main>
  )
}

export default CalendarEvent