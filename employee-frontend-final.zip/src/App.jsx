import './App.css';
import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login/Login';
import Leave from './components/Leave/Leave';
import Home from './components/Home/Home';
import Employees from './components/Employees/Employees';
import Events from './components/Events/Events';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = (username, password, navigate) => {
    // Implement authentication logic here (e.g., check hardcoded credentials)
    if (username === 'gowtam_manager' && password === 'Gowtam@2024') {
      setIsLoggedIn(true);
      navigate('/home'); // Redirect to the /home route after successful login
    } else {
      // Handle invalid credentials, maybe show an error message
      console.log('Invalid credentials');
    }
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/login"
          element={<Login onLogin={handleLogin} />} // Pass handleLogin function to Login component
        />
        {isLoggedIn ? (
          <>
            <Route path="/home" element={<Home />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/events" element={<Events />} />
            <Route path="/leaves" element={<Leave />} />
          </>
        ) : (
          <Route path="*" element={<Navigate to="/login" />} />
        )}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
